export const walletIcons = {
  "Coinbase Wallet": "/connectors/coinbaseWalletIcon.svg",
  "Brave Wallet": "/connectors/icn-bravewallet.svg",
  Metamask: "/connectors/icn-metamask.svg",
  imToken: "/connectors/icn-imtoken.svg",
  Wallet: "/connectors/icn-metamask.svg",
  "Trust Wallet": "/connectors/icon-trust.svg",
};
